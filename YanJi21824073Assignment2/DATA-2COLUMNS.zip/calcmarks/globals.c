#include  "calcmarks.h"              // we use double-quotes

// calcmarks, version 1, released Thu Sep 15 14:26:09 WST 2016

double    projmarks[ MAXMARKS ];     // array's size is defined
double    exammarks[ MAXMARKS ];     // array's size is defined

bool      verbose = false;           // global is initialized
